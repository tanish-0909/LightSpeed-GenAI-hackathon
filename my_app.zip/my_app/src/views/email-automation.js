import React, { Fragment } from 'react'

import { Helmet } from 'react-helmet'

import Registeremail from '../components/registeremail'
import Numemails from '../components/numemails'
import './email.css'

const EmailAutomation = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Showy Self Reliant Rook</title>
        <meta property="og:title" content="Showy Self Reliant Rook" />
      </Helmet>
      <Registeremail
        action1={
          <Fragment>
            <span className="home-text1">Sign In</span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="home-text2">
              Are you looking to enhance customer engagement and drive better
              results for your business? Our personalized email automation
              feature is designed to help you connect with your consumer base in
              a professional and impactful way.
            </span>
          </Fragment>
        }
        content2={
          <Fragment>
            <span className="home-text3">
              plz Sign up for our newsletter to receive updates and promotions
            </span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="home-text4">AI Email Automation</span>
          </Fragment>
        }
      ></Registeremail>
      <Numemails
        heading1={
          <Fragment>
            <span className="home-text5">
              Your Emails are two simple clicks away
            </span>
          </Fragment>
        }
      ></Numemails>
    </div>
  )
}

export default EmailAutomation